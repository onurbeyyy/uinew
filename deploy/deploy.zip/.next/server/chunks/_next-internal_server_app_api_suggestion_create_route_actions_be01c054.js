module.exports=[39270,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_suggestion_create_route_actions_be01c054.js.map