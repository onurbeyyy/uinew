module.exports=[60630,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_game_leaderboard_%5BgameType%5D_%5Bcount%5D_route_actions_b11d9ce3.js.map