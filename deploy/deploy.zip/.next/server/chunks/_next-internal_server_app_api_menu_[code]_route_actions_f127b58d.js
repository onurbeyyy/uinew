module.exports=[30958,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_menu_%5Bcode%5D_route_actions_f127b58d.js.map