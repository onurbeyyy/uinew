module.exports=[96331,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_register_route_actions_3564e727.js.map