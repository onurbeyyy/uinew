module.exports=[65467,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}a.s(["default",()=>c,"metadata",0,{title:"Self-Servis QR Sistemi",description:"Self-servis QR kod ekranı - Tablet/TV için"}])}];

//# sourceMappingURL=app_self-service_layout_tsx_1bbfe1d3._.js.map