module.exports=[83487,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_okey_join_%5BodaId%5D_page_actions_e4210444.js.map