module.exports=[56836,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_self-service_page_actions_e64da763.js.map