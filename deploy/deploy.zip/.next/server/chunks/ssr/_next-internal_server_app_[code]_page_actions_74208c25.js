module.exports=[5221,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Bcode%5D_page_actions_74208c25.js.map