module.exports=[929,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_game_submit_route_actions_b222c591.js.map