module.exports=[47158,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_token-settings_%5Bcode%5D_route_actions_c1832ef7.js.map