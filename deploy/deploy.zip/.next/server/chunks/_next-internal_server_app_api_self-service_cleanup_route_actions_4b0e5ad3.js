module.exports=[4781,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_self-service_cleanup_route_actions_4b0e5ad3.js.map