module.exports=[34172,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_categories_%5Bcode%5D_route_actions_d5aea190.js.map