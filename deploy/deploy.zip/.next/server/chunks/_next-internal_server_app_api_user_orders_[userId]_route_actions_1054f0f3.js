module.exports=[32396,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_orders_%5BuserId%5D_route_actions_1054f0f3.js.map