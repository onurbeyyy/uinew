module.exports=[39952,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_order_route_actions_4b10d906.js.map