module.exports=[22620,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_advertisements_%5Bcode%5D_route_actions_e2f6a79a.js.map