module.exports=[83299,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_game_player_%5Bnickname%5D_stats_route_actions_082d083a.js.map