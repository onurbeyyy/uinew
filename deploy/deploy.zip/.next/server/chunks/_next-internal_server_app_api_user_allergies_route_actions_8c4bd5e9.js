module.exports=[30401,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_allergies_route_actions_8c4bd5e9.js.map