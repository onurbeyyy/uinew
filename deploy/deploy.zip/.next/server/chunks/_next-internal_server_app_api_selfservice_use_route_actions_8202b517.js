module.exports=[65294,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_selfservice_use_route_actions_8202b517.js.map