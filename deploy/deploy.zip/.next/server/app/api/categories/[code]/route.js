var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__5a96e48e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_categories_[code]_route_actions_d5aea190.js")
R.m(43629)
module.exports=R.m(43629).exports
