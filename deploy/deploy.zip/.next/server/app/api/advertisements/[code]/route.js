var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/advertisements/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__c8cd5ed6._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_advertisements_[code]_route_actions_e2f6a79a.js")
R.m(89112)
module.exports=R.m(89112).exports
