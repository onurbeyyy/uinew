var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/customers/active/route.js")
R.c("server/chunks/[root-of-the-server]__8fba3fdf._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_customers_active_route_actions_6516b908.js")
R.m(32705)
module.exports=R.m(32705).exports
