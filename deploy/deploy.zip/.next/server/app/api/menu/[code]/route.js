var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/menu/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__7e19f26c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_menu_[code]_route_actions_f127b58d.js")
R.m(50599)
module.exports=R.m(50599).exports
