var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/self-service/cleanup/route.js")
R.c("server/chunks/[root-of-the-server]__962eb83c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_self-service_cleanup_route_actions_4b0e5ad3.js")
R.m(71293)
module.exports=R.m(71293).exports
