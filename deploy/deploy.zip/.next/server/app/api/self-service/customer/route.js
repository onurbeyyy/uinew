var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/self-service/customer/route.js")
R.c("server/chunks/[root-of-the-server]__b70762a2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_self-service_customer_route_actions_734e0c15.js")
R.m(40124)
module.exports=R.m(40124).exports
