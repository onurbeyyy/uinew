var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/self-service/validate-session/route.js")
R.c("server/chunks/[root-of-the-server]__8155e5bc._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/ce889_server_app_api_self-service_validate-session_route_actions_fc33af0d.js")
R.m(21168)
module.exports=R.m(21168).exports
