var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/self-service/create-session/route.js")
R.c("server/chunks/[root-of-the-server]__bd4fa3cc._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_self-service_create-session_route_actions_8eb68377.js")
R.m(65889)
module.exports=R.m(65889).exports
