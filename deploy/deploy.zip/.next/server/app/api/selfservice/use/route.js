var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/selfservice/use/route.js")
R.c("server/chunks/[root-of-the-server]__d33e960c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_selfservice_use_route_actions_8202b517.js")
R.m(57385)
module.exports=R.m(57385).exports
