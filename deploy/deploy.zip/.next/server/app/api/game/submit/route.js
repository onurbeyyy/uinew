var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/game/submit/route.js")
R.c("server/chunks/[root-of-the-server]__6c0ecde2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_game_submit_route_actions_b222c591.js")
R.m(60908)
module.exports=R.m(60908).exports
