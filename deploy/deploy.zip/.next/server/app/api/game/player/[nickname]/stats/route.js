var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/game/player/[nickname]/stats/route.js")
R.c("server/chunks/[root-of-the-server]__3a63fdf6._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/ce889_server_app_api_game_player_[nickname]_stats_route_actions_082d083a.js")
R.m(44079)
module.exports=R.m(44079).exports
