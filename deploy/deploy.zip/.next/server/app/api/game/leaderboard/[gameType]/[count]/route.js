var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/game/leaderboard/[gameType]/[count]/route.js")
R.c("server/chunks/[root-of-the-server]__1398c5b7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/ce889_server_app_api_game_leaderboard_[gameType]_[count]_route_actions_b11d9ce3.js")
R.m(98884)
module.exports=R.m(98884).exports
