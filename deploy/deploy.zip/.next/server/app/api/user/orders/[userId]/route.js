var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/orders/[userId]/route.js")
R.c("server/chunks/[root-of-the-server]__0c467eb2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_user_orders_[userId]_route_actions_1054f0f3.js")
R.m(1581)
module.exports=R.m(1581).exports
