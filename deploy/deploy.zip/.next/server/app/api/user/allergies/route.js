var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/allergies/route.js")
R.c("server/chunks/[root-of-the-server]__06f628af._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_user_allergies_route_actions_8c4bd5e9.js")
R.m(65097)
module.exports=R.m(65097).exports
