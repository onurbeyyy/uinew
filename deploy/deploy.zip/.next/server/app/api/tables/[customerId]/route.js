var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tables/[customerId]/route.js")
R.c("server/chunks/[root-of-the-server]__628c658d._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_tables_[customerId]_route_actions_f453b68a.js")
R.m(91161)
module.exports=R.m(91161).exports
