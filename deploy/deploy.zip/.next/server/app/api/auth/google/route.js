var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/route.js")
R.c("server/chunks/[root-of-the-server]__3bd53b70._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_route_actions_5a4bf5a2.js")
R.m(88214)
module.exports=R.m(88214).exports
