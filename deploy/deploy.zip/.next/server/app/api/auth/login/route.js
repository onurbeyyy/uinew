var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__1d6f946e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_d02a8f19.js")
R.m(74378)
module.exports=R.m(74378).exports
