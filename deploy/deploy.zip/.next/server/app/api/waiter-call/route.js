var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/waiter-call/route.js")
R.c("server/chunks/[root-of-the-server]__e9253058._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_waiter-call_route_actions_fd4d7006.js")
R.m(16723)
module.exports=R.m(16723).exports
