var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/order/route.js")
R.c("server/chunks/[root-of-the-server]__7593a7de._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_order_route_actions_4b10d906.js")
R.m(46486)
module.exports=R.m(46486).exports
