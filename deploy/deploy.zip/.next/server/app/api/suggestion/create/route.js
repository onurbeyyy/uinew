var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/suggestion/create/route.js")
R.c("server/chunks/[root-of-the-server]__514a1919._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_suggestion_create_route_actions_be01c054.js")
R.m(41007)
module.exports=R.m(41007).exports
