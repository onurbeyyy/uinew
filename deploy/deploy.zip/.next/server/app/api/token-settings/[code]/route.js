var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/token-settings/[code]/route.js")
R.c("server/chunks/[root-of-the-server]__519d292a._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_token-settings_[code]_route_actions_c1832ef7.js")
R.m(89929)
module.exports=R.m(89929).exports
