globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/664adc71bc2617c2.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/54229609c6616d22.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/e68109d3fa50257e.js",
    "static/chunks/28f2072f5c1bcc28.js",
    "static/chunks/turbopack-f6b59259fc3d0be7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];